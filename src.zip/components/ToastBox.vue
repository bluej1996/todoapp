<template>
    <div class="toast-box">
        <div 
            v-for:="item in toasts"
            :key="item.id"
            class="alert" 
            :class="`alert-${item.type}`" 
            role="alert"
        >
        {{ item.message }}
        </div>
    </div>
</template>
<script>
    import { useToast } from '@/composables/toast.js'
    export default {
        setup() {
            const toasts = useToast();
            return {
                toasts
            }
        }
    }
</script>
<style scoped>
    .toast-box {
        position: fixed;
        top: 30px;
        right: 10px;
    }
</style>