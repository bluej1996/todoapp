<template>
    <h1>About page</h1>
</template>
<script>
export default {
    setup() {
        
    },
}
</script>
<style>

</style>