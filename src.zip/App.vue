<template>
  <!-- 상단메뉴 -->
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
      <router-link class="nav-link" :to="{name: 'Home' }">Home</router-link>
      <router-link class="nav-link" :to="{name: 'Todos' }">Todos</router-link>
      <router-link class="nav-link" :to="{name: 'About' }">About</router-link>
      <router-link class="nav-link" :to="{name: 'Profile' }">Profile</router-link>    
      
    </div>
  </nav>
  <!-- router -->
  <div class="container">
    <router-view />
    <!-- slide transition 걸기 -->
    <transition name="slide">
    <!-- 안내창 -->
      <ToastBox />  
    </transition>
  </div>
  
</template>

<script>
  import ToastBox from '@/components/ToastBox.vue';
  import { useToast } from '@/composables/toast.js';
  export default {
    components: {
      ToastBox
    },
    setup() {
      const {
        showToast,
        toastMessage,
        triggerToast,
        toastAlertType
      } = useToast();
      
      return {
        showToast,
        toastMessage,
        triggerToast,
        toastAlertType
      }
    }
  }
</script>

<style scoped>
  .slide-enter-active,
  .slide-leave-acvice{
    transition: all 0.5s ease;
  }
  .slide-enter-from,
  .slide-leave-to{
    opacity: 0;
    transition: translateY(-30px);
  }
  .slide-enter-to,
  .slide-leave-from{
    opacity: 1;
    transition: translateY(0px);
  }
</style>